#!/bin/bash

# npm run typeorm:run-migrations

node ./src/main.js
