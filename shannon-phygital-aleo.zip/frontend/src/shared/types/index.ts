export interface AleoStruct {
    privateKey: string;
    address: string;
    viewKey: string;
}
