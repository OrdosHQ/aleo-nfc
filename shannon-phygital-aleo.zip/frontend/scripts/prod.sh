#!/bin/bash

# npm run typeorm:run-migrations

npm start
